/** HKwest.js | JavaScript AJAX/CORS Library
 * @author Oyedele Hammed Horlah
 * @version 1.5
 * @since September 5, 2017
 * @see http://www.oyedelehammed.ml/HKwest.html
*/

function HKwest( url, opt ) {
  var xhr = (window.XMLHttpRequest) ? new XMLHttpRequest() : new XDomainRequest();
  opt = opt || {};
  var serialize = function( obj ) {
    if ( typeof obj == 'object' ) {
      var res = [];
      for ( var key in obj ) {
        res.push( key + '=' + encodeURIComponent( obj[key] ) );
      }
      return res.join( '&' );
    } else {
      return obj;
    }
  }
  xhr.open( opt.type || 'GET', url || '#hk', true );
  xhr.withCredentials = true;
  xhr.setRequestHeader( 'X-Requested-With', 'XMLHttpRequest' );
  if ( opt.headers ) {
    for ( var h in opt.headers ) {
      xhr.setRequestHeader( h, opt.headers[h] );
    }
  }
  var type = (opt.type) ? opt.type.toUpperCase() : 'GET';
  if ( (type == 'POST' || type == 'PUT' || type == 'PATCH') && opt.data ) {
    xhr.setRequestHeader( 'Content-type', opt.contentType || 'application/www-form-url-encoded' );
  }
  if ( opt.mime ) {
    xhr.overrideMimeType( opt.mime );
  }
  if ( opt.returns ) {
    xhr.responseType = opt.returns;
  }
  if ( opt.auth ) {
    xhr.setRequestHeader( 'Authorization', 'Basic ' + btoa( opt.auth ) );
  }
  xhr.onload = function() {
    if ( xhr.readyState != 4 ) return;
    if ( opt.done ) {
      opt.done( xhr );
    } else {
      var res = xhr.responseText;
    }
  }
  if ( (type == 'POST' || type == 'PUT' || type == 'PATCH') && opt.data ) {
    var data = serialize( opt.data );
  }
  xhr.send( data || null );
  return res || null;
}