function HTemplate( tpl, data ) {
  var fn = new Function( "h",
    "var res =" +
    JSON.stringify( tpl )
      .replace(/\{\{(.+?)\}\}/gm, '" + ($1) + "')
      .replace(/\{%(.+?)%\}/gm, '"; $1\nres +="')
      .replace(/\{#(.+?)#\}/gm, '') +
    "; return res;" );
  return data ? fn( data ) : fn;
}