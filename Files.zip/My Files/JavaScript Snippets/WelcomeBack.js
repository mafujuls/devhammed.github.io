function WelcomeBack( url, days ) {
  days = days || 1;
  window.ck = function ck( key, value, day ) {
    if ( arguments.length > 1 ) {
      var d = new Date;
      d.setTime(d.getTime() + 24 * 60 * 60 * 1000 * day );
      return (
        document.cookie = key + "=" + value + "; expires=" + d.toGMTString()
      );
    }
    var cks = document.cookie.match("(^|;) ?" + key + "=([^;]*)(;|$)");
    return cks ? cks[2] : null;
  }
  if ( !ck("WBJS") ) {
    if ( url && ("Audio" in window) && ("play" in window.Audio) ) {
      var audio = new Audio(url);
      audio.play();
    } else {
      alert("Thanks for visiting today, new goodies are waiting you!");
    }
    ck( "WBJS", "t", days );
    return true;
  }
  return false;
}