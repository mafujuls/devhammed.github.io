<?php
defined('_JEXEC') or die('Restricted access');

class HomePageViewHomePage extends JViewLegacy
{

	function display($tpl = null) 	{

		$this->msg = 'Hello World';

		parent::display($tpl);
	}
}
