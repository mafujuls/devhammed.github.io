<?php
defined('_JEXEC') or die('Restricted access');
?>
<style>
#what div {
border-bottom: 2px solid #ccc;
padding-top: 8px;
padding-bottom: 8px;
margin-top: 2px;
margin-bottom: 2px;
}
</style>
<div class="row-fluid">
<div class="span5 h-panel">
<h3 class="text-blue">About Us</h3>
<div><img src="/templates/protostar/img/girl.jpg" /></div>
<div>BrightSMS is a web-based Mobile communications platform that allows you to send text messages from your computer to mobile phones and direct from your mobile phone with or without internet connection at once and is the quickest and cheapest means of sending messages.</div>
</div>
<div class="span7 h-panel" id="what">
<h3 class="text-blue">What can we <b>Do</b> for you</h3>
<div>
<span class="icon-pen lg pull-left light-grey"></span> &nbsp;<h4 class="text-orange">Get free SMS on Registration</h4>
Get 5 Free SMS when you register with us. Remember, registration is absolutely free.
</div>
<div>
<span class="icon-office lg pull-left light-grey"></span> &nbsp;<h4 class="text-orange">Become an SMS Reseller</h4>
You can be your own boss and earn extra income. Becoming a Reseller takes less than 3 minutes.
</div>
<div>
<span class="icon-stats lg pull-left light-grey"></span> &nbsp;<h4 class="text-orange">99.9% SMS Delivery Rate Guaranteed</h4>
We guarantee 99.9% SMS delivery of all traffic from our website. Monitor the progress of your SMS in realtime.
</div>
</div>
</div>