<?php
defined('_JEXEC') or die('Restricted access');

class HomePageController extends JControllerLegacy
{
}
