<?php
  defined('_JEXEC') or die;
  $app  = JFactory::getApplication();
  $user = JFactory::getUser();
  $this->setHtml5(true);
  $params = $app->getTemplate(true)->params;
  $option = $app->input->getCmd('option', '');
  $view = $app->input->getCmd('view', '');
  $layout = $app->input->getCmd('layout', '');
  $task = $app->input->getCmd('task', '');
  $itemid = $app->input->getCmd('Itemid', '');
  $sitename = $app->get('sitename');
  if ( $task === 'edit' || $layout === 'form' ) {
    $fullWidth = 1;
  } else {
    $fullWidth = 0;
  }
  JHtml::_('bootstrap.framework');
  JHtml::_( 'script', 'template.js', array( 'version' => 'auto', 'relative' => true ) );
  JHtml::_( 'script', 'jui/html5.js', array( 'version' => 'auto', 'relative' => true, 'conditional' => 'lt IE 9' ) );
  JHtml::_( 'stylesheet', 'template.css', array( 'version' => 'auto', 'relative' => true ) );
  if ( $this->params->get('googleFont') ) {
    	JHtml::_( 'stylesheet', '//fonts.googleapis.com/css?family=' . $this->params->get('googleFontName') );
    	$this->addStyleDeclaration("
      h1, h2, h3, h4, h5, h6, .site-title {
      font-family: '" . str_replace('+', ' ', $this->params->get('googleFontName')) . "', sans-serif;
    }");
  }
  if ( $this->params->get('templateColor') ) {
    	$this->addStyleDeclaration('
	      body.site {
        padding: 5px!important;
	        border-top: 8px solid ' . $this->params->get('templateColor') . ';
        border-bottom: 5px solid ' . $this->params->get('templateColor'). ';
        border-radius: 8px;
        margin-top: 15px;
        margin-bottom: 15px;
		        background-color: #fff;
      }
      a {
        color: #08c;
        text-decoration: none;
      }
      .lg { font-size: 40px!important; display: inline!important; }
      h1 { font-size: 36px!important; }
      h2 { font-size: 30px!important; }
      h3 { font-size: 24px!important; }
      h4,
      body {
        font-size: 20px!important;
      }
      h5 { font-size: 18px!important; }
      h6 { font-size: 6px!important; }
      .menu li {
        display: inline-block;
      }
      .article-info,
      .page-header,
      .icons {
        display: none!important;
      }
      nav,
      header,
      footer {
        width: 100%;
        margin: auto;
        display: block;
      }
      @media (max-width: 600px) {
        div {
          width: 100%!important;
          margin: auto!important;
        }
      }
      .menu li a,
      .h-button {
        border: 0;
        display: inline-block;
        outline: 0;
        padding: 8px 16px;
        vertical-align: middle;
        overflow: hidden;
        text-decoration: none;
        color: #ff9800!important;
        text-align: center;
        cursor: pointer;
        white-space: nowrap;
      }
	      .nav-list > .active > a,
	      .nav-list > .active > a:hover,
	      .dropdown-menu li > a:hover,
	      .dropdown-menu .active > a,
	      .dropdown-menu .active > a:hover,
	      .nav-pills > .active > a,
	      .nav-pills > .active > a:hover,
	      .btn-primary,
      .menu > .active > a {
        color: #fff!important;
		        background: ' . $this->params->get('templateColor') . ';
      }
    ');
  }
  JHtml::_( 'stylesheet', 'user.css', array( 'version' => 'auto', 'relative' => true ) );
  JHtml::_( 'script', 'user.js', array( 'version' => 'auto', 'relative' => true ) );
  JHtml::_( 'bootstrap.loadCss', false, $this->direction );
  $position7ModuleCount = $this->countModules('position-7');
  $position8ModuleCount = $this->countModules('position-8');
  if ( $position7ModuleCount && $position8ModuleCount ) {
    	$span = 'span6';
  } elseif ( $position7ModuleCount && !$position8ModuleCount ) {
    	$span = 'span9';
  } elseif ( !$position7ModuleCount && $position8ModuleCount ) {
    	$span = 'span9';
  } else {
	    $span = 'span12';
  }
  $logo = '<img src="/templates/protostar/img/logo.jpg" alt="BrightSMSWorld Logo" />';
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="http://www.yomsms.com/templates/rsaria/css/icons.css" />
    <jdoc:include type="head" />
  </head>
  <body class="site <?php echo $option
    . ' view-' . $view
    . ($layout ? ' layout-' . $layout : ' no-layout')
    . ($task ? ' task-' . $task : ' no-task')
    . ($itemid ? ' itemid-' . $itemid : '')
    . ' container';
    echo ( $this->direction === 'rtl' ? ' rtl' : '' );
  ?>">
    <!-- Body -->
    <div class="body" id="top">
      <div class="container-fluid">
        <!-- Header -->
        <header class="header row-fluid" role="banner">
          <div class="span4">
            <?php echo $logo; ?>
          </div>
          <div class="span4">
            <p><a href="http://www.facebook.com/Brightsmsworld"><span class="icon-facebook"></span> &nbsp;Like us on Facebook</a></p>
          </div>
          <div class="header-search span4">
            <jdoc:include type="modules" name="position-0" style="none" />
          </div>
        </header>
        <?php if ( $this->countModules('position-1') ) : ?>
          <nav class="navigation container-fluid" role="navigation" style="padding: 10px;">
            <div class="light-grey container-fluid">
              <jdoc:include type="modules" name="position-1" style="none" />
            </div>
          </nav>
        <?php endif; ?>
        <div class="container-fluid pull-left">
          <div class="h-panel">&nbsp;</div>
          <jdoc:include type="modules" name="banner" style="xhtml" />
          <?php if ( $option == 'com_homepage' ) : ?>
            <div class="h-panel"></div>
            <div class="row-fluid h-panel">
              <div class="span4 orange text-white h-panel">
                <h3><span class="icon-library lg"></span> &nbsp;Reseller</h3>
                <div class="h-panel">
                  You can launch your own branded SMS Reseller website like ours and enjoy customized website (no programming knowledge required).
                </div>
                <p><a class="h-button btn-primary" href="index.php/reseller">Read More</a></p>
              </div>
              <div class="span4 orange text-white h-panel">
                <h3><span class="icon-books lg"></span> &nbsp;Keyword Hosting</h3>
                <div class="h-panel">
                  The Keyword Hosting platform is easy to use ensuring that anyone situated anywhere can have access to world of Long Codes and all auxillary services.
                </div>
                <p><a class="h-button btn-primary" href="index.php/our-services/keyword-hosting">Read More</a></p>
              </div>
              <div class="span4 orange text-white h-panel">
                <h3><span class="icon-newspaper lg"></span> &nbsp;Contact Us</h3>
                <div class="h-panel">
                  No. 40, Benin / Auchi road, Irrua, Edo state, Nigeria.<br />
                  Email: info@brightsmsworld.com<br />
                  http://www.brightsmsworld.com<br />
                </div>
                <p><a class="h-button btn-primary" href="index.php/contact-us">Read More</a></p>
              </div>
            <?php endif; ?>
          </div>
          <div class="clearfix"></div>
          <?php if ( $option == 'com_homepage' ) : ?>
            <div class="row-fluid light-grey h-panel" style="text-align: center;">
              <div class="span1 pull-left h-panel">
                <p></p>
                <div class="icon-shuffle lg">&nbsp;</div>
                <p></p>
              </div>
              <div class="span9">
                <h3 class="text-blue">Buy SMS Online and get credited instantly</h3>
                <div>You can now buy SMS using your ATM Card, Bank Transfer, Bank Deposit, Internet Banking or by Credit card.</div>
              </div>
              <div class="span2">
                <a class="h-button pull-right btn-primary h-panel" href="index.php/pricing">Read More</a>
              </div>
            </div>
            <div class="clearfix"></div>
          <?php endif; ?>
          <div class="row-fluid">
            <?php if ( $position8ModuleCount ) : ?>
              					<!-- Begin Sidebar -->
                <div id="sidebar" class="span3">
                  <div class="sidebar-nav">
                    <jdoc:include type="modules" name="position-8" style="xhtml" />
                  </div>
                </div>
              <!-- End Sidebar -->
            <?php endif; ?>
            <main id="content" role="main" class="<?php echo $span; ?>">
              <!-- Begin Content -->
                <jdoc:include type="modules" name="position-2" style="none" />
                <jdoc:include type="message" />
                <jdoc:include type="component" />
                <jdoc:include type="modules" name="position-3" style="xhtml" />
              <!-- End Content -->
            </main>
            <?php if ( $position7ModuleCount ) : ?>
              <div id="aside" class="span3 light-grey">
                <!-- Begin Right Sidebar -->
                  <div class="dark-grey">
                    <jdoc:include type="modules" name="position-7" style="well" />
                  </div>
                <!-- End Right Sidebar -->
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <!-- Footer -->
        <footer class="footer" role="contentinfo">
          <div class="h-panel">
            <?php if ( $option == 'com_homepage' ) { ?>
              <div class="row-fluid h-panel">
                <div class="span6 h-panel">
                  <h3 class="text-blue">Our Value Added Services</h3>
                  <!-- VAS -->
                </div>
                <div class="h-panel span6">
                  <h3 class="text-blue">How to Buy SMS and Pay</h3>
                  <img class="pull-left" src="/templates/protostar/img/buy.jpg" alt="How to Buy SMS and Pay" />
                  <div>
                    Just pay into any of our Bank Accounts below, then send email to <b>info@brightsmsworld.com</b> containing the NAME and AMOUNT you paid.<br />NOTE:- Use your USERNAME as the DEPOSITOR NAME when you are paying.
                  </div>
                  <div class="clearfix"></div>
                  <p><a class="h-button btn-primary" href="index.php/pricing">View our Pricing(s)</a></p>
                </div>
              </div>
            <?php } else { ?>
              <div class="h-panel">
                <p><img src="/templates/protostar/img/money.jpg" alt="make money" /></p>
              </div>
            <?php } ?>
          </div>
          <div class="h-panel dark-grey" style="text-align: center;">
            <p>"Now BrightSMS allows you to send SMS in more than one way.<br> Download BrightSMS Smartphone applications for your Android, iOS, Symbian and WebOS phones and enjoy new way of bulk SMS messaging,<br> and they are absolutely free."</p>
          </div>
          <div class="row-fluid h-panel">
            <div class="h-panel span6">
              <h3 class="text-blue">Bank account Information</h3>
              <div>
                <p><img src="/templates/protostar/img/payment.jpg" alt="Bank account information" /></p>
              </div>
            </div>
            <div class="h-panel span6">
              <h3 class="text-blue">Quick Contact</h3>
              <form class="h-panel" method="POST" action="mail.php">
                <input name="name" type="text" value="" placeholder="Name..." />
                <input name="email" type="text" value="" placeholder="Email..." />
                <input name="subject" type="text" value="" placeholder="Subject..." />
                <textarea name="message">Message...</textarea>
                <input class="btn-primary" type="submit" value="Send Feedback" />
              </form>
            </div>
          </div>
          <div class="row-fluid h-panel" style="margin: 0 auto;text-align: center;">
            <p><img src="/templates/protostar/img/text-it.jpg" style="width: 80%;" alt="Text-it feature" /></p>
          </div>
          <p>&copy; <?php echo date('Y'); ?> BrightSMSWorld Inc.			</p>
        </footer>
        <jdoc:include type="modules" name="debug" style="none" />
  </body>
</html>