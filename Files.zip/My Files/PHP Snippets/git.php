<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Git Push</title>
  </head>
  <body>
    <?php
      if ( isset( $_POST['push'] ) ) {
        $path = $_POST['path'];
        $message = $_POST['message'];
        $branch = $_POST['branch'];
        if ( !empty( $_POST['file_url'] ) ) {
          $file = $_POST['file_url'];
        } elseif ( isset( $_FILES['file'] ) && !empty( $_FILES['file'] ) ) {
          $file = $_FILES['file']['tmp_name'];
        }
        $content = base64_encode( file_get_contents( $file ) );
        $repo_url = $_POST['repo_url'];
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $data = json_encode( array(
          'message' => $message,
          'content' => $content,
          'branch' => $branch
        ));
        $auth = $user.':'.$pass;
        $options = array(
          CURLOPT_RETURNTRANSFER => 1,
          CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
          CURLOPT_USERAGENT => $user,
          CURLOPT_USERPWD => $auth,
          CURLOPT_CUSTOMREQUEST => "PUT",
          CURLOPT_POSTFIELDS => $data
        );
        $url = 'https://api.github.com/repos/'.$repo_url.'/contents/'.$path;
        $ch = curl_init( $url );
        curl_setopt_array( $ch, $options );
        echo '<pre>'.curl_exec( $ch ).'</pre>';
        curl_close( $ch );
      }
    ?>
    <form method="POST" enctype="multipart/form-data">
      <label for="user">Username:</label><br>
      <input id="user" name="user" type="text" value="<?php echo $user; ?>" placeholder="Username" /><br>
      <label for="pass">Password:</label><br>
      <input id="pass" name="pass" type="text" value="<?php echo $pass; ?>" placeholder="Password" /><br>
      <label for="repo_url">Repository Path:</label><br>
      <input id="repo_url" name="repo_url" type="text" placeholder="e.g User/Repo_Name" value="<?php echo $repo_url; ?>" /><br>
      <hr>
      <b>Upload File or Enter file URL:</b><br>
      <label for="file_url">Enter file url:</label><br>
      <input id="file_url" name="file_url" type="text" value="" /><br>
      <label for="file">Or upload the file:</label><br>
      <input id="file" name="file" type="file" /><br>
      <hr>
      <label for="path">File Path:</label><br>
      <input id="path" name="path" type="text" placeholder="Save as..." value="" /><br>
      <label for="message">Commit message:</label><br>
      <input id="message" name="message" type="text" value="Initial commit" /><br>
      <label for="branch">Branch:</label><br>
      <input id="branch" name="branch" type="text" value="master" /><br>
      <input name="push" type="submit" value="Push" />
    </form>
    <p>Copyright 2017 - Oyedele Hammed Horlah</p>
  </body>
</html>