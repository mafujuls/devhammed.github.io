<?php
  if ( $_POST['submit'] == "" ) {
?>
    <form  action="" method="POST" enctype="multipart/form-data">
      <label for="name">Your name:</label><br>
      <input id="name" name="name" type="text" value="" size="30"/><br>
      <label for="email">Your email:</label><br>
      <input id="email" name="email" type="text" value="" size="30"/><br>
      <label for="to">Receiver(s) [separate multiple emails by comma]:</label><br>
      <input id="to" name="to" type="text" value="" size="30" /><br>
      <label for="subject">Subject:</label><br>
      <input id="subject" name="subject" type="text" value="" size="30" /><br>
      <label for="message">Message:</label><br>
      <textarea id="message" name="message" rows="7" cols="30"></textarea><br>
      <input name="submit" type="submit" value="Send"/>
    </form>
<?php
  } else {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $to = $_POST['to'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    if ( ($name == "") || ($to == "") || ($subject == "") || ($email == "") || ($message == "") ) {
      	echo 'All fields are required, please fill <a href="">the form</a> again.';
    } else {		
      $from = "From: $name<$email>\r\nReturn-path: $email";
      if ( 		mail( $to, $subject, $message, $from ) ) {
        		echo "Email(s) sent successfully.";
      } else {
        echo 'Sending Error: '.$php_errormsg;
      }
    }
  }
?>