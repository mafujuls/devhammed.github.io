<?php
/* PHP Fake Traffic Crawler
 * Author: Oyedele Hammed Horlah
 * Release Date: December 11
 * Version: 1.0
 * Copyright: 2017 - Present
*/

$limit = $_GET['limit'];
$url = $_GET['url'];
$sent = 0;
$refs = array(
'https://www.google.com',
'https://www.facebook.com',
'https://www.yahoo.com',
'https://www.alexa.com',
'https://mobile.twitter.com',
'http://www.nairaland.com',
'https://mail.google.com'
);
$ref = array_rand($refs);
$agents = array(
'Firefox',
'Chrome',
'Opera',
'Edge',
'Safari',
'UC Browser',
'Dolphin',
'Android KitKat'
);
$agent = array_rand($agents);
$opts = array(
CURLOPT_RETURNTRANSFER => 1,
CURLOPT_USERAGENT => $agents[$agent],
CURLOPT_FOLLOWLOCATION => 1,
CURLOPT_MAXREDIRS => 5,
CURLOPT_REFERER => $refs[$ref],
CURLOPT_SSL_VERIFYPEER => false
);
$ch = curl_init($url);
curl_setopt_array($ch, $opts);
for ($i = 0; $i < $limit; $i++) {
if (curl_exec($ch)) {
$sent++;
  }
}
curl_close($ch);
if ($sent == $limit) {
echo "{$sent} traffics has been sent to {$url} successfully.";
} else {
echo "Error completing traffic generation, Completed: {$sent} .";
}
?>