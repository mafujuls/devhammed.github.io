<?php
 $codex = $_POST["code"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>HorlahTryIt Editor - Test HTML5, CSS3, HStack, HScript and Javascript Codes</title>
<link rel="stylesheet" href="h.css" />
<script src="horlah.js"></script>
</head>
<body>
<header class="h-teal h-container">
<h1>HorlahTryIt Editor - Run And Test Your HTML5, CSS3 and Javascript, HStack and HScript Codes Here</h1>
</header>
<main class="h-container">
<br/>
<br/>
<form method="post">
<textarea name="code" size="100%" class="h-input h-border">
<?php echo $codex; ?>
</textarea>
<input class="h-button" type="submit" name="run" value="RUN" />
</form>
<br/><br/>
<?php
if (isset($_POST['run'])) {
echo "Result: <br/>";
echo $codex." <br/> <br/>";
}
?>
<script src="HStack.js"></script> <br/>
</main>
<footer class="h-teal h-container">
<h3>Copyright <?=date('Y');?> - <a href="/" title="View my portfolio">Oyedele Hammed Horlah</a></h3>
</footer>
</body>
</html>
