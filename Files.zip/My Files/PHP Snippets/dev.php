<?php
  $path = explode( '/', $_SERVER['PATH_INFO'] );
  array_shift( $path );
  $users = array(
    'Horlahcoded' => "A self-taught Web Developer having proficiency in HTML5, CSS3, Javascript and Others",
    'Dealwap' => "The founder of NCT.COM.NG",
    'Evans' => "A Cool Java and Firebase Developer",
    'Gabriel' => "Upcoming programmer",
    'Aphatheology' => "A procastinator of programming"
  );
  $user = $path[ 0 ];
  if ( isset( $users[$user] ) ) {
    echo "<h1>Biography of {$user}</h1>";
    echo '<p>'.$users[$user].'</p>';
  } else {
    echo '<h1>Users</h1>';
    echo '<ul>';
    foreach ( $users as $k => $_ ) {
      echo "<li><a href='/dev.php/{$k}'>{$k}</a></li>";
    }
    echo '</ul>';
  }
?>